// blockchain-listener/src/utils/constants.js

// Solana Program IDs
const TOKEN_PROGRAM_ID = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
const ASSOCIATED_TOKEN_PROGRAM_ID = 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';
const SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID = 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';

// Metaplex Metadata Program ID
const METADATA_PROGRAM_ID = 'metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s';

// DEX Program IDs
const RAYDIUM_LIQUIDITY_PROGRAM_ID = '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8';
const RAYDIUM_AMM_PROGRAM_ID = '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8';
const ORCA_SWAP_PROGRAM_ID = '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM';
const ORCA_AQUAFARM_PROGRAM_ID = '82yxjeMsvaURa4MbZZ7WZZHfobirZYkH1zF8fmeGtyaQ';

// Jupiter Aggregator Program ID
const JUPITER_PROGRAM_ID = 'JUP4Fb2cqiRUcaTHdrPC8h2gNsA2ETXiPDD33WcGuJB';

// Serum DEX Program IDs
const SERUM_DEX_PROGRAM_ID = '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin';
const SERUM_DEX_V3_PROGRAM_ID = 'srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX';

// Popular Solana Token Addresses
const WSOL_ADDRESS = 'So11111111111111111111111111111111111111112'; // Wrapped SOL
const USDC_ADDRESS = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'; // USD Coin
const USDT_ADDRESS = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB'; // Tether USD
const RAY_ADDRESS = '4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R'; // Raydium
const SRM_ADDRESS = 'SRMuApVNdxXokk5GT7XD5cUUgXMBCoAz2LHeuAoKWRt'; // Serum

// Token Metadata Constants
const TOKEN_METADATA_SEED = 'metadata';
const EDITION_SEED = 'edition';
const MASTER_EDITION_SEED = 'edition';

// Token Standards
const TOKEN_STANDARD = {
  NON_FUNGIBLE: 'NonFungible',
  FUNGIBLE_ASSET: 'FungibleAsset',
  FUNGIBLE: 'Fungible',
  NON_FUNGIBLE_EDITION: 'NonFungibleEdition',
  PROGRAMMABLE_NON_FUNGIBLE: 'ProgrammableNonFungible'
};

// Account Data Sizes
const MINT_SIZE = 82; // Size of token mint account
const ACCOUNT_SIZE = 165; // Size of token account
const MULTISIG_SIZE = 355; // Size of multisig account

// Token Categories
const TOKEN_CATEGORIES = {
  MEMECOIN: 'MEMECOIN',
  STABLECOIN: 'STABLECOIN',
  DEFI: 'DEFI',
  NFT: 'NFT',
  GAMING: 'GAMING',
  UTILITY: 'UTILITY',
  GOVERNANCE: 'GOVERNANCE'
};

// Token Status
const TOKEN_STATUS = {
  NEW: 'NEW',
  GRADUATING: 'GRADUATING',
  GRADUATED: 'GRADUATED',
  DELISTED: 'DELISTED',
  INACTIVE: 'INACTIVE'
};

// Memecoin Keywords for Detection
const MEMECOIN_KEYWORDS = [
  'meme', 'doge', 'shib', 'pepe', 'cat', 'inu', 'moon', 'elon', 'safe',
  'baby', 'mini', 'floki', 'wojak', 'chad', 'based', 'chad', 'bonk',
  'samo', 'cope', 'rope', 'ape', 'banana', 'monkey', 'frog', 'trump',
  'biden', 'tesla', 'spacex', 'mars', 'rocket', 'lambo', 'diamond',
  'hands', 'hodl', 'yolo', 'wagmi', 'ngmi', 'gm', 'gn', 'ser'
];

// Memecoin Name Patterns
const MEMECOIN_NAME_PATTERNS = [
  /\b(doge|shib|inu|pepe|floki|bonk|samo)\b/i,
  /\b(baby|mini|micro|nano|pico)\s+\w+/i,
  /\b\w+(coin|token|finance|swap|protocol)\b/i,
  /\b(safe|moon|mars|rocket|lambo)\w*/i,
  /\b(elon|musk|tesla|spacex)\w*/i
];

// Common DEX Pool Identifiers
const DEX_POOL_IDENTIFIERS = {
  RAYDIUM_AMM: 'RaydiumAMM',
  RAYDIUM_CPMM: 'RaydiumCPMM',
  ORCA_WHIRLPOOL: 'OrcaWhirlpool',
  ORCA_STABLE: 'OrcaStable',
  SERUM_MARKET: 'SerumMarket'
};

// Liquidity Thresholds
const LIQUIDITY_THRESHOLDS = {
  MIN_MEMECOIN_LIQUIDITY_USD: 1000,    // $1,000 minimum liquidity
  GRADUATING_LIQUIDITY_USD: 50000,     // $50,000 to start graduating
  GRADUATED_LIQUIDITY_USD: 250000,     // $250,000 to be considered graduated
  MINIMUM_VOLUME_24H_USD: 100         // $100 minimum 24h volume
};

// Token Supply Thresholds
const SUPPLY_THRESHOLDS = {
  MIN_MEMECOIN_SUPPLY: 1000000,        // 1M minimum supply
  MAX_MEMECOIN_SUPPLY: 1000000000000,  // 1T maximum supply
  TYPICAL_MEMECOIN_SUPPLY: 1000000000  // 1B typical supply
};

// Price Change Thresholds (in percentage)
const PRICE_CHANGE_THRESHOLDS = {
  PUMP_THRESHOLD: 50,      // 50% increase considered a pump
  DUMP_THRESHOLD: -30,     // 30% decrease considered a dump
  VOLATILE_THRESHOLD: 25   // 25% change in either direction is volatile
};

// Time Constants (in milliseconds)
const TIME_CONSTANTS = {
  MINUTE: 60 * 1000,
  HOUR: 60 * 60 * 1000,
  DAY: 24 * 60 * 60 * 1000,
  WEEK: 7 * 24 * 60 * 60 * 1000,
  MONTH: 30 * 24 * 60 * 60 * 1000
};

// API Rate Limits
const RATE_LIMITS = {
  SOLANA_RPC_REQUESTS_PER_SECOND: 10,
  METADATA_REQUESTS_PER_SECOND: 5,
  EXTERNAL_API_REQUESTS_PER_MINUTE: 100
};

// Error Codes
const ERROR_CODES = {
  TOKEN_NOT_FOUND: 'TOKEN_NOT_FOUND',
  INVALID_TOKEN_DATA: 'INVALID_TOKEN_DATA',
  METADATA_FETCH_FAILED: 'METADATA_FETCH_FAILED',
  LIQUIDITY_CHECK_FAILED: 'LIQUIDITY_CHECK_FAILED',
  BLOCKCHAIN_CONNECTION_ERROR: 'BLOCKCHAIN_CONNECTION_ERROR',
  DATABASE_ERROR: 'DATABASE_ERROR',
  CACHE_ERROR: 'CACHE_ERROR'
};

// Retry Configuration
const RETRY_CONFIG = {
  MAX_RETRIES: 3,
  RETRY_DELAY_MS: 1000,
  EXPONENTIAL_BACKOFF: true,
  JITTER: true
};

// Health Check Constants
const HEALTH_CHECK = {
  BLOCKCHAIN_CONNECTION_TIMEOUT: 5000,
  DATABASE_CONNECTION_TIMEOUT: 3000,
  CACHE_CONNECTION_TIMEOUT: 2000,
  SERVICE_CHECK_INTERVAL: 30000
};

// Popular Memecoin Contract Addresses (for reference/comparison)
const POPULAR_MEMECOINS = {
  BONK: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
  SAMO: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
  COPE: '8HGyAAB1yoM1ttS7pXjHMa3dukTFGQWKb5h8hrBBW45Q',
  ROPE: '8PMHT4swUMtBzgHnh5U564N5sjPSiUz2cjEQzFnnP1Fo'
};

export {
  // Program IDs
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID,
  RAYDIUM_LIQUIDITY_PROGRAM_ID,
  RAYDIUM_AMM_PROGRAM_ID,
  ORCA_SWAP_PROGRAM_ID,
  ORCA_AQUAFARM_PROGRAM_ID,
  JUPITER_PROGRAM_ID,
  SERUM_DEX_PROGRAM_ID,
  SERUM_DEX_V3_PROGRAM_ID,

  // Token Addresses
  WSOL_ADDRESS,
  USDC_ADDRESS,
  USDT_ADDRESS,
  RAY_ADDRESS,
  SRM_ADDRESS,

  // Metadata Constants
  TOKEN_METADATA_SEED,
  EDITION_SEED,
  MASTER_EDITION_SEED,
  TOKEN_STANDARD,

  // Account Sizes
  MINT_SIZE,
  ACCOUNT_SIZE,
  MULTISIG_SIZE,

  // Enums
  TOKEN_CATEGORIES,
  TOKEN_STATUS,
  DEX_POOL_IDENTIFIERS,

  // Detection Arrays
  MEMECOIN_KEYWORDS,
  MEMECOIN_NAME_PATTERNS,

  // Thresholds
  LIQUIDITY_THRESHOLDS,
  SUPPLY_THRESHOLDS,
  PRICE_CHANGE_THRESHOLDS,

  // Time and Rate Limits
  TIME_CONSTANTS,
  RATE_LIMITS,

  // Error Handling
  ERROR_CODES,
  RETRY_CONFIG,

  // Health Check
  HEALTH_CHECK,

  // Popular Tokens
  POPULAR_MEMECOINS,
  METADATA_PROGRAM_ID
};

