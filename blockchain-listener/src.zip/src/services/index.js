// Services index file

import tokenService from './token.service.js';

const services = {
  // Export services here, e.g.,
  tokenService,
};

export default services;